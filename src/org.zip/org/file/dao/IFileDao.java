package org.file.dao;

public interface IFileDao {

}
