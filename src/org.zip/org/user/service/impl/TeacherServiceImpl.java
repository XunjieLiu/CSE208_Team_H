package org.user.service.impl;

import org.user.entity.Teacher;
import org.user.service.ITeacherService;

public class TeacherServiceImpl implements ITeacherService {

	@Override
	public boolean queryByNameAndPassword(Teacher teacher) {
		// TODO Auto-generated method stub
		return false;
	}

}