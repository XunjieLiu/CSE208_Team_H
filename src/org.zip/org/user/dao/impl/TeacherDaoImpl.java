package org.user.dao.impl;

public class TeacherDaoImpl {

}
