package org.user.dao.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.user.dao.IStudentDao;
import org.user.entity.Student;
import org.user.util.UserUtil;

public class StudentDaoImpl implements IStudentDao {

	private static final String URL = "jdbc:mysql://localhost:3306/test1?serverTimezone=GMT%2B8&useSSL=false";
	private static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";

	private static final String USER = "root";
	private static final String PASSWORD = "liuxunjie1997";
	
	static Connection conn = null;
	static PreparedStatement statement = null;
	static ResultSet result = null;
	
	public boolean isExist(int id) {
		return queryStudentById(id)==null?false:true;
	}
	
	public boolean updateStudentById(int id, Student student) {
		try {
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(URL, USER, PASSWORD);
			
			String sql = "UPDATE student SET sid = ?, sname = ?, sage = ?, saddress = ? WHERE sid = ?";
			
			PreparedStatement statement = conn.prepareStatement(sql);
//			
//			statement.setInt(1, student.getSno());
//			statement.setString(2, student.getName());
//			statement.setInt(3, student.getAge());
//			statement.setString(4, student.getAddress());
			statement.setInt(5, id);
			
			int count = statement.executeUpdate();

			if(count > 0) {
				return true;
			}else {
				return false;
			}
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
			return false;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}finally {
			try {
				if(conn != null) conn.close();
				if(statement != null) statement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public boolean deleteStudentById(int id) {
		try {
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(URL, USER, PASSWORD);
			
			String sql = "DELETE FROM student WHERE sid = ?";
			
			PreparedStatement statement = conn.prepareStatement(sql);
			
			statement.setInt(1, id);
			
			int count = statement.executeUpdate();

			if(count > 0) {
				return true;
			}else {
				return false;
			}
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
			return false;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}finally {
			try {
				if(conn != null) conn.close();
				if(statement != null) statement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public boolean addStudent(Student student) {
		try {
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(URL, USER, PASSWORD);
			
			String sql = "INSERT INTO student(sname, spwd, sgender, suniv, smajor, syear, smodule, semail, sqna, sidentity) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
			
			PreparedStatement statement = conn.prepareStatement(sql);

			statement.setString(1, student.getSname());
			statement.setString(2, student.getSpwd());
			statement.setInt(3, student.getSgender());
			statement.setString(4, student.getSuniv());
			statement.setString(5, student.getSmajor());
			statement.setInt(6, student.getSyear());
			statement.setString(7, student.getSmodule());
			statement.setString(8, student.getSemail());
			statement.setString(9, "This is Q&A");
			statement.setString(10, String.valueOf(student.getSidentity()));
			
			int count = statement.executeUpdate();

			if(count > 0) {
				return true;
			}else {
				System.out.println("addStudent--count<0");
				return false;
			}
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
			return false;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}finally {
			try {
				if(conn != null) conn.close();
				if(statement != null) statement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public List<Student> queryAllStudent() {
		ArrayList<Student> all = new ArrayList<>();
		try {
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(URL, USER, PASSWORD);
			
			String sql = "SELECT * FROM student";
			PreparedStatement statement = conn.prepareStatement(sql);
			
			result = statement.executeQuery();

			while(result.next()) {
				String name = result.getString("sname");
				int sid = result.getInt("sid");
				int age = result.getInt("sage");
				String address = result.getString("saddress");
				
//				all.add(new Student(sid, name, age, address));
			}
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
			return null;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}finally {
			try {
				if(conn != null) conn.close();
				if(statement != null) statement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return all;
	}
	
	public Student queryStudentById(int id) {
		Student student = null;
		try {
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(URL, USER, PASSWORD);
			
			String sql = "SELECT * FROM student WHERE sid = ?";
			PreparedStatement statement = conn.prepareStatement(sql);
			
			statement.setInt(1, id);
			
			result = statement.executeQuery();

			if(result.next()) {
				String name = result.getString("sname");
				int sid = result.getInt("sid");
				int age = result.getInt("sage");
				String address = result.getString("saddress");
//				
//				student = new Student(sid, name, age, address);
			}
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
			return null;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}finally {
			try {
				if(conn != null) conn.close();
				if(statement != null) statement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return student;
	}

	@Override
	public boolean queryByNameAndPassword(Student student) {
		// TODO Auto-generated method stub
		return false;
	}
	
//	public static void main(String[] args) {
//		StudentDaoImpl studentDao = new StudentDaoImpl();
//		Student student = new Student("Xunjie", "123");
//		System.out.println(studentDao.addStudent(student));
//		
//	}

}
