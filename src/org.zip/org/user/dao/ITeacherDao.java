package org.user.dao;

public interface ITeacherDao {

}
